import React, { createContext, useContext, useState, useCallback } from 'react';
import { toast } from '@/components/ui/use-toast';

export type Platform = 'tiktok' | 'instagram' | 'youtube' | 'twitter' | 'linkedin';
export type MonetizationGoal = 'affiliate' | 'sponsorships' | 'products' | 'ads' | 'coaching';
export type ActiveView = 'dashboard' | 'editor' | 'roadmap' | 'community' | 'reports';

export interface UserProfile {
  name: string;
  niche: string;
  platforms: Platform[];
  monetizationGoal: MonetizationGoal;
  followerCount: number;
  weeklyPosts: number;
  onboardingComplete: boolean;
}

export interface ContentDraft {
  id: string;
  title: string;
  body: string;
  platform: Platform;
  score: number;
  published: boolean;
  createdAt: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedAt?: string;
}

export interface StreakData {
  current: number;
  longest: number;
  lastPublishDate: string;
  totalPublished: number;
}

export interface ChallengeDay {
  day: number;
  task: string;
  category: string;
  completed: boolean;
}

export interface CommunityPost {
  id: string;
  niche: string;
  day: number;
  score: number;
  platform: Platform;
  timeAgo: string;
}

export interface WeeklyBrief {
  ideas: string[];
  topPerformingHook: string;
  postsLastWeek: number;
  avgScore: number;
}

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  userProfile: UserProfile;
  setUserProfile: (profile: UserProfile) => void;
  showOnboarding: boolean;
  setShowOnboarding: (show: boolean) => void;
  drafts: ContentDraft[];
  addDraft: (draft: ContentDraft) => void;
  updateDraft: (id: string, updates: Partial<ContentDraft>) => void;
  publishDraft: (id: string) => void;
  deleteDraft: (id: string) => void;
  streak: StreakData;
  badges: Badge[];
  earnBadge: (id: string) => void;
  estimatedEarnings: number;
  firstDollarProgress: number;
  challengeDays: ChallengeDay[];
  completeChallenge: (day: number) => void;
  communityFeed: CommunityPost[];
  weeklyBrief: WeeklyBrief;
  showAuthModal: boolean;
  setShowAuthModal: (show: boolean) => void;
  currentLevel: number;
  xp: number;
}

const defaultProfile: UserProfile = {
  name: '',
  niche: '',
  platforms: [],
  monetizationGoal: 'affiliate',
  followerCount: 0,
  weeklyPosts: 0,
  onboardingComplete: false,
};

const defaultBadges: Badge[] = [
  { id: 'first-post', name: 'First Post', description: 'Published your very first piece of content', icon: 'pen', earned: false },
  { id: 'streak-3', name: '3-Day Streak', description: 'Published 3 days in a row', icon: 'flame', earned: false },
  { id: 'streak-7', name: 'Week Warrior', description: 'Published 7 days in a row', icon: 'shield', earned: false },
  { id: 'streak-30', name: '30-Day Legend', description: 'Completed the 30-day challenge', icon: 'crown', earned: false },
  { id: 'score-80', name: 'Quality Creator', description: 'Achieved a content score of 80+', icon: 'star', earned: false },
  { id: 'score-95', name: 'Masterpiece', description: 'Achieved a content score of 95+', icon: 'gem', earned: false },
  { id: 'multi-platform', name: 'Multi-Platform', description: 'Published on 3+ platforms', icon: 'globe', earned: false },
  { id: 'first-dollar', name: 'First Dollar', description: 'Earned your first dollar from content', icon: 'dollar', earned: false },
  { id: 'ten-posts', name: 'Prolific Creator', description: 'Published 10 pieces of content', icon: 'layers', earned: false },
  { id: 'community', name: 'Community Star', description: 'Reached the community leaderboard', icon: 'users', earned: false },
];

const defaultChallengeDays: ChallengeDay[] = Array.from({ length: 30 }, (_, i) => {
  const categories = ['Finding Ideas', 'Finding Ideas', 'Finding Ideas', 'Finding Ideas', 'Finding Ideas', 'Finding Ideas',
    'Writing', 'Writing', 'Writing', 'Writing', 'Writing', 'Writing',
    'Publishing', 'Publishing', 'Publishing', 'Publishing', 'Publishing', 'Publishing',
    'Growth', 'Growth', 'Growth', 'Growth', 'Growth', 'Growth',
    'Monetization', 'Monetization', 'Monetization', 'Monetization', 'Monetization', 'Monetization'];
  const tasks = [
    'List 10 topics you could talk about forever',
    'Find 5 creators in your niche and note what works',
    'Write down 3 problems your audience faces',
    'Browse trending topics and pick one to riff on',
    'Create a content idea bank with 20 ideas',
    'Pick your best 7 ideas for this week',
    'Write a hook that stops the scroll',
    'Draft your first post using the AIDA framework',
    'Write a personal story related to your niche',
    'Create a listicle post (Top 5/7/10)',
    'Write a controversial take in your niche',
    'Draft a how-to tutorial post',
    'Publish your first post on your primary platform',
    'Publish and engage with 10 comments in your niche',
    'Cross-post your best content to a second platform',
    'Publish a video or carousel post',
    'Publish a thread or multi-part story',
    'Repurpose your best post into a different format',
    'Analyze your top-performing post and double down',
    'Engage with 20 accounts in your niche daily',
    'Collaborate with another creator (comment, duet, quote)',
    'Create a lead magnet or freebie for your audience',
    'Optimize your bio and profile for conversions',
    'Run a poll or Q&A to boost engagement',
    'Research 3 affiliate programs in your niche',
    'Write a product review or recommendation post',
    'Create a "resources I use" post with affiliate links',
    'Draft your first sponsorship pitch template',
    'Plan a simple digital product (checklist, template, guide)',
    'Celebrate! Review your journey and plan Month 2',
  ];
  return {
    day: i + 1,
    task: tasks[i],
    category: categories[i],
    completed: false,
  };
});

const defaultCommunityFeed: CommunityPost[] = [
  { id: '1', niche: 'Fitness', day: 22, score: 91, platform: 'instagram', timeAgo: '2m ago' },
  { id: '2', niche: 'Tech Reviews', day: 15, score: 87, platform: 'youtube', timeAgo: '5m ago' },
  { id: '3', niche: 'Personal Finance', day: 30, score: 94, platform: 'twitter', timeAgo: '8m ago' },
  { id: '4', niche: 'Cooking', day: 7, score: 78, platform: 'tiktok', timeAgo: '12m ago' },
  { id: '5', niche: 'Photography', day: 19, score: 88, platform: 'instagram', timeAgo: '18m ago' },
  { id: '6', niche: 'SaaS', day: 11, score: 82, platform: 'linkedin', timeAgo: '25m ago' },
  { id: '7', niche: 'Travel', day: 28, score: 90, platform: 'tiktok', timeAgo: '32m ago' },
  { id: '8', niche: 'Parenting', day: 5, score: 73, platform: 'instagram', timeAgo: '45m ago' },
  { id: '9', niche: 'Gaming', day: 14, score: 85, platform: 'youtube', timeAgo: '1h ago' },
  { id: '10', niche: 'Design', day: 21, score: 92, platform: 'twitter', timeAgo: '1h ago' },
];

const defaultWeeklyBrief: WeeklyBrief = {
  ideas: [
    'Share your morning routine and how it fuels creativity',
    'Break down a trending topic in your niche with a hot take',
    'Create a "before and after" transformation post',
    'Interview a follower or peer creator in your niche',
    'Share 3 tools that changed your workflow this month',
  ],
  topPerformingHook: 'The curiosity hook ("Most people don\'t know this about...")',
  postsLastWeek: 4,
  avgScore: 76,
};

const AppContext = createContext<AppContextType>({} as AppContextType);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [userProfile, setUserProfile] = useState<UserProfile>(defaultProfile);
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [drafts, setDrafts] = useState<ContentDraft[]>([]);
  const [badges, setBadges] = useState<Badge[]>(defaultBadges);
  const [streak, setStreak] = useState<StreakData>({ current: 0, longest: 0, lastPublishDate: '', totalPublished: 0 });
  const [challengeDays, setChallengeDays] = useState<ChallengeDay[]>(defaultChallengeDays);
  const [communityFeed] = useState<CommunityPost[]>(defaultCommunityFeed);
  const [weeklyBrief] = useState<WeeklyBrief>(defaultWeeklyBrief);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [xp, setXp] = useState(0);

  const toggleSidebar = useCallback(() => setSidebarOpen(prev => !prev), []);

  const addDraft = useCallback((draft: ContentDraft) => {
    setDrafts(prev => [draft, ...prev]);
    toast({ title: 'Draft saved', description: 'Your content has been saved as a draft.' });
  }, []);

  const updateDraft = useCallback((id: string, updates: Partial<ContentDraft>) => {
    setDrafts(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));
  }, []);

  const publishDraft = useCallback((id: string) => {
    setDrafts(prev => prev.map(d => d.id === id ? { ...d, published: true } : d));
    setStreak(prev => ({
      current: prev.current + 1,
      longest: Math.max(prev.longest, prev.current + 1),
      lastPublishDate: new Date().toISOString(),
      totalPublished: prev.totalPublished + 1,
    }));
    setXp(prev => prev + 50);
    toast({ title: 'Content Published!', description: '+50 XP earned. Keep the streak going!' });
  }, []);

  const deleteDraft = useCallback((id: string) => {
    setDrafts(prev => prev.filter(d => d.id !== id));
    toast({ title: 'Draft deleted', description: 'Your draft has been removed.' });
  }, []);

  const earnBadge = useCallback((id: string) => {
    setBadges(prev => prev.map(b => b.id === id ? { ...b, earned: true, earnedAt: new Date().toISOString() } : b));
    const badge = defaultBadges.find(b => b.id === id);
    setXp(prev => prev + 100);
    if (badge) {
      toast({ title: `Badge Earned: ${badge.name}!`, description: `${badge.description}. +100 XP!` });
    }
  }, []);

  const completeChallenge = useCallback((day: number) => {
    setChallengeDays(prev => prev.map(d => d.day === day ? { ...d, completed: true } : d));
    setXp(prev => prev + 25);
    toast({ title: `Day ${day} Complete!`, description: '+25 XP earned. On to the next challenge!' });
  }, []);

  const estimatedEarnings = (() => {
    const { followerCount, weeklyPosts } = userProfile;
    const engagementRate = 0.035;
    const reachMultiplier = 0.15;
    const affiliateRate = 0.02;
    const sponsorRate = followerCount > 1000 ? 0.01 : 0;
    const adRate = followerCount > 5000 ? 0.003 : 0;
    const monthlyReach = followerCount * reachMultiplier * weeklyPosts * 4;
    return Math.round((monthlyReach * engagementRate * (affiliateRate + sponsorRate + adRate)) * 100) / 100;
  })();

  const firstDollarProgress = Math.min(100, (estimatedEarnings / 1) * 100);
  const currentLevel = Math.floor(xp / 500) + 1;

  return (
    <AppContext.Provider value={{
      sidebarOpen, toggleSidebar,
      activeView, setActiveView,
      userProfile, setUserProfile,
      showOnboarding, setShowOnboarding,
      drafts, addDraft, updateDraft, publishDraft, deleteDraft,
      streak, badges, earnBadge,
      estimatedEarnings, firstDollarProgress,
      challengeDays, completeChallenge,
      communityFeed, weeklyBrief,
      showAuthModal, setShowAuthModal,
      currentLevel, xp,
    }}>
      {children}
    </AppContext.Provider>
  );
};
