import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Navbar from './contentos/Navbar';
import Dashboard from './contentos/Dashboard';
import ContentEditor from './contentos/ContentEditor';
import Roadmap from './contentos/Roadmap';
import Community from './contentos/Community';
import Reports from './contentos/Reports';
import OnboardingModal from './contentos/OnboardingModal';
import AuthModal from './contentos/AuthModal';
import LandingHero from './contentos/LandingHero';
import Footer from './contentos/Footer';

const AppLayout: React.FC = () => {
  const { activeView, userProfile } = useAppContext();
  const isMobile = useIsMobile();

  const renderView = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard />;
      case 'editor':
        return <ContentEditor />;
      case 'roadmap':
        return <Roadmap />;
      case 'community':
        return <Community />;
      case 'reports':
        return <Reports />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Modals */}
      <OnboardingModal />
      <AuthModal />

      {/* Navbar - always visible */}
      <Navbar />

      {/* Main Content */}
      {!userProfile.onboardingComplete ? (
        <>
          <LandingHero />
          <Footer />
        </>
      ) : (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-8">
          {renderView()}
        </main>
      )}

      {/* Footer for authenticated views */}
      {userProfile.onboardingComplete && <Footer />}
    </div>
  );
};

export default AppLayout;
