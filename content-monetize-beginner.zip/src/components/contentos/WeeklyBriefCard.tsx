import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Sparkles, ChevronRight, Lightbulb, TrendingUp, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const WeeklyBriefCard: React.FC = () => {
  const { weeklyBrief, userProfile, setActiveView } = useAppContext();
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);

  const copyIdea = (idea: string, idx: number) => {
    navigator.clipboard.writeText(idea).catch(() => {});
    setCopiedIdx(idx);
    toast({ title: 'Idea copied!', description: 'Paste it into the editor to start creating.' });
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="p-5 border-b border-slate-100 bg-gradient-to-r from-violet-50 to-indigo-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-200">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-slate-900">AI Weekly Brief</h3>
              <p className="text-xs text-slate-500">Personalized for {userProfile.niche || 'your niche'}</p>
            </div>
          </div>
          <span className="text-xs font-medium text-violet-600 bg-violet-100 px-2.5 py-1 rounded-full">This Week</span>
        </div>
      </div>

      {/* Performance Summary */}
      <div className="p-5 border-b border-slate-100">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="w-4 h-4 text-emerald-500" />
          <span className="text-sm font-medium text-slate-700">Last Week's Performance</span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-xl bg-slate-50">
            <p className="text-2xl font-bold text-slate-900">{weeklyBrief.postsLastWeek}</p>
            <p className="text-xs text-slate-500">Posts Created</p>
          </div>
          <div className="p-3 rounded-xl bg-slate-50">
            <p className="text-2xl font-bold text-slate-900">{weeklyBrief.avgScore}</p>
            <p className="text-xs text-slate-500">Avg. Score</p>
          </div>
        </div>
        <div className="mt-3 p-3 rounded-xl bg-amber-50 border border-amber-100">
          <p className="text-xs text-amber-800">
            <span className="font-semibold">Best hook style:</span> {weeklyBrief.topPerformingHook}
          </p>
        </div>
      </div>

      {/* Ideas */}
      <div className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-4 h-4 text-amber-500" />
          <span className="text-sm font-medium text-slate-700">5 Content Ideas for This Week</span>
        </div>
        <div className="space-y-2">
          {weeklyBrief.ideas.map((idea, idx) => (
            <div
              key={idx}
              className="group flex items-start gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
              onClick={() => copyIdea(idea, idx)}
            >
              <span className="flex-shrink-0 w-6 h-6 rounded-lg bg-violet-100 text-violet-600 text-xs font-bold flex items-center justify-center mt-0.5">
                {idx + 1}
              </span>
              <p className="text-sm text-slate-700 flex-1 leading-relaxed">{idea}</p>
              <div className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
                {copiedIdx === idx ? (
                  <Check className="w-4 h-4 text-emerald-500" />
                ) : (
                  <Copy className="w-4 h-4 text-slate-400" />
                )}
              </div>
            </div>
          ))}
        </div>
        <Button
          onClick={() => setActiveView('editor')}
          className="w-full mt-4 gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700 shadow-lg shadow-violet-200"
        >
          Start Creating <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

export default WeeklyBriefCard;
