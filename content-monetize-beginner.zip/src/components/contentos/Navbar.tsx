import React from 'react';
import { useAppContext, ActiveView } from '@/contexts/AppContext';
import {
  LayoutDashboard, PenTool, Map, Users, BarChart3,
  Menu, X, Zap, Bell, LogIn
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const navItems: { view: ActiveView; label: string; icon: React.ReactNode }[] = [
  { view: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-4 h-4" /> },
  { view: 'editor', label: 'Create', icon: <PenTool className="w-4 h-4" /> },
  { view: 'roadmap', label: 'Roadmap', icon: <Map className="w-4 h-4" /> },
  { view: 'community', label: 'Community', icon: <Users className="w-4 h-4" /> },
  { view: 'reports', label: 'Reports', icon: <BarChart3 className="w-4 h-4" /> },
];

const Navbar: React.FC = () => {
  const { activeView, setActiveView, sidebarOpen, toggleSidebar, streak, currentLevel, xp, setShowAuthModal, userProfile } = useAppContext();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-200 bg-white/80 backdrop-blur-xl">
      <div className="flex h-16 items-center justify-between px-4 lg:px-8">
        {/* Left: Logo + Mobile Menu */}
        <div className="flex items-center gap-3">
          <button onClick={toggleSidebar} className="lg:hidden p-2 rounded-lg hover:bg-slate-100 transition-colors">
            {sidebarOpen ? <X className="w-5 h-5 text-slate-600" /> : <Menu className="w-5 h-5 text-slate-600" />}
          </button>
          <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setActiveView('dashboard')}>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-200">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-violet-700 to-indigo-600 bg-clip-text text-transparent hidden sm:block">
              ContentOS
            </span>
          </div>
        </div>

        {/* Center: Nav Items (Desktop) */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map(item => (
            <button
              key={item.view}
              onClick={() => setActiveView(item.view)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                activeView === item.view
                  ? 'bg-violet-100 text-violet-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </nav>

        {/* Right: Stats + Auth */}
        <div className="flex items-center gap-3">
          {userProfile.onboardingComplete && (
            <>
              {/* Streak Badge */}
              <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200">
                <div className="w-4 h-4 text-orange-500">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 23c-3.866 0-7-3.134-7-7 0-3.866 3.134-7 7-7s7 3.134 7 7c0 3.866-3.134 7-7 7zm0-2c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm-1-8V7.5c0-.276.224-.5.5-.5h1c.276 0 .5.224.5.5V13h-2z"/></svg>
                </div>
                <span className="text-xs font-bold text-orange-700">{streak.current}</span>
              </div>

              {/* Level Badge */}
              <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gradient-to-r from-violet-50 to-indigo-50 border border-violet-200">
                <Zap className="w-3.5 h-3.5 text-violet-500" />
                <span className="text-xs font-bold text-violet-700">Lv.{currentLevel}</span>
                <span className="text-xs text-violet-500">{xp} XP</span>
              </div>

              {/* Notifications */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="relative p-2 rounded-lg hover:bg-slate-100 transition-colors">
                    <Bell className="w-5 h-5 text-slate-500" />
                    <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-72">
                  <div className="p-3 border-b">
                    <p className="text-sm font-semibold text-slate-900">Notifications</p>
                  </div>
                  <DropdownMenuItem className="p-3 cursor-pointer">
                    <div>
                      <p className="text-sm font-medium">Weekly Brief Ready</p>
                      <p className="text-xs text-slate-500">5 new content ideas for your niche</p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="p-3 cursor-pointer">
                    <div>
                      <p className="text-sm font-medium">Streak Reminder</p>
                      <p className="text-xs text-slate-500">Don't forget to publish today!</p>
                    </div>
                  </DropdownMenuItem>
                  <DropdownMenuItem className="p-3 cursor-pointer">
                    <div>
                      <p className="text-sm font-medium">New Badge Available</p>
                      <p className="text-xs text-slate-500">You're close to earning "Week Warrior"</p>
                    </div>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}

          {/* Auth Button */}
          <Button
            onClick={() => setShowAuthModal(true)}
            variant="outline"
            size="sm"
            className="gap-2 border-violet-200 text-violet-700 hover:bg-violet-50"
          >
            <LogIn className="w-4 h-4" />
            <span className="hidden sm:inline">Sign In</span>
          </Button>
        </div>
      </div>

      {/* Mobile Nav */}
      {sidebarOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white p-2">
          {navItems.map(item => (
            <button
              key={item.view}
              onClick={() => { setActiveView(item.view); toggleSidebar(); }}
              className={`flex items-center gap-3 w-full px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                activeView === item.view
                  ? 'bg-violet-100 text-violet-700'
                  : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
};

export default Navbar;
