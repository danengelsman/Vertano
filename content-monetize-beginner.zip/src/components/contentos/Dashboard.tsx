import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import FirstDollarTracker from './FirstDollarTracker';
import StatsCards from './StatsCards';
import WeeklyBriefCard from './WeeklyBriefCard';
import BadgesGrid from './BadgesGrid';
import { Rocket, PenTool, ArrowRight, Sparkles, Clock, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Dashboard: React.FC = () => {
  const { userProfile, setActiveView, streak, communityFeed } = useAppContext();

  return (
    <div className="space-y-8">
      {/* Welcome Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-violet-950 to-indigo-950 p-8 lg:p-10">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItSDI0di0yaDEyem0wLTRWMjhIMjR2Mmgxem0tMTYgNnYtMkg0djJoMTZ6bTAtOHYtMkg0djJoMTZ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
        <div className="relative flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-amber-400" />
              <span className="text-sm font-medium text-amber-400">
                {streak.current > 0 ? `${streak.current}-day streak!` : 'Day 1 starts now'}
              </span>
            </div>
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">
              Welcome back, {userProfile.name || 'Creator'}
            </h1>
            <p className="text-lg text-white/70 max-w-xl">
              {streak.current === 0
                ? "Ready to start your content journey? Let's create your first post and take the first step toward your first dollar."
                : `You're on a ${streak.current}-day streak! Keep the momentum going and watch your audience grow.`
              }
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <Button
                onClick={() => setActiveView('editor')}
                className="gap-2 bg-white text-slate-900 hover:bg-white/90 shadow-xl h-11 px-6"
              >
                <PenTool className="w-4 h-4" /> Create Content
              </Button>
              <Button
                onClick={() => setActiveView('roadmap')}
                variant="outline"
                className="gap-2 border-white/20 text-white hover:bg-white/10 h-11 px-6"
              >
                <Rocket className="w-4 h-4" /> View Roadmap
              </Button>
            </div>
          </div>
          {/* Quick Actions */}
          <div className="flex flex-col gap-3 w-full lg:w-auto">
            <div className="flex items-center gap-3 p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 cursor-pointer hover:bg-white/15 transition-colors" onClick={() => setActiveView('editor')}>
              <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                <Zap className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">5-Minute Post</p>
                <p className="text-xs text-white/50">Quick content from AI ideas</p>
              </div>
              <ArrowRight className="w-4 h-4 text-white/40 ml-auto" />
            </div>
            <div className="flex items-center gap-3 p-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 cursor-pointer hover:bg-white/15 transition-colors" onClick={() => setActiveView('roadmap')}>
              <div className="w-10 h-10 rounded-lg bg-violet-500/20 flex items-center justify-center">
                <Clock className="w-5 h-5 text-violet-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-white">Today's Challenge</p>
                <p className="text-xs text-white/50">Continue your 30-day journey</p>
              </div>
              <ArrowRight className="w-4 h-4 text-white/40 ml-auto" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <StatsCards />

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Left: First Dollar + Community */}
        <div className="lg:col-span-3 space-y-6">
          <FirstDollarTracker />

          {/* Community Activity */}
          <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-semibold text-slate-900">Community Activity</h3>
              <button
                onClick={() => setActiveView('community')}
                className="text-xs font-medium text-violet-600 hover:text-violet-700 flex items-center gap-1"
              >
                View All <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="divide-y divide-slate-100">
              {communityFeed.slice(0, 5).map(post => (
                <div key={post.id} className="flex items-center gap-4 p-4 hover:bg-slate-50 transition-colors">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-400 to-indigo-500 flex items-center justify-center text-white text-xs font-bold">
                    {post.niche[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-700">
                      A <span className="font-medium">{post.niche}</span> creator just posted their <span className="font-medium">Day {post.day}</span> content
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">{post.timeAgo} · {post.platform}</p>
                  </div>
                  <div className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    post.score >= 90 ? 'bg-emerald-100 text-emerald-700' :
                    post.score >= 80 ? 'bg-blue-100 text-blue-700' :
                    'bg-amber-100 text-amber-700'
                  }`}>
                    {post.score}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Weekly Brief + Badges */}
        <div className="lg:col-span-2 space-y-6">
          <WeeklyBriefCard />
          <BadgesGrid />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
