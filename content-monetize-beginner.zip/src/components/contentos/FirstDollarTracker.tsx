import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { DollarSign, TrendingUp, ArrowUpRight } from 'lucide-react';


const FirstDollarTracker: React.FC = () => {
  const { estimatedEarnings, firstDollarProgress, userProfile } = useAppContext();
  const remaining = Math.max(0, 1 - estimatedEarnings);

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-violet-600 via-indigo-600 to-purple-700 p-6 lg:p-8 text-white shadow-xl">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />

      <div className="relative">
        <div className="flex items-start justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
              <span className="text-sm font-medium text-white/80">First Dollar Tracker</span>
            </div>
            <h3 className="text-3xl lg:text-4xl font-bold">
              ${estimatedEarnings.toFixed(2)}
            </h3>
            <p className="text-white/70 text-sm mt-1">
              {remaining > 0
                ? `$${remaining.toFixed(2)} away from your first dollar`
                : 'Congratulations! You reached your first dollar!'
              }
            </p>
          </div>
          <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-white/20 backdrop-blur-sm text-sm font-medium">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+12%</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-white/70 mb-2">
            <span>Progress to $1.00</span>
            <span>{Math.round(firstDollarProgress)}%</span>
          </div>
          <div className="h-3 bg-white/20 rounded-full overflow-hidden backdrop-blur-sm">
            <div
              className="h-full bg-gradient-to-r from-amber-400 to-yellow-300 rounded-full transition-all duration-1000 ease-out"
              style={{ width: `${firstDollarProgress}%` }}
            />
          </div>
        </div>

        {/* Revenue Breakdown */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Affiliate', value: (estimatedEarnings * 0.5).toFixed(2), growth: '+8%' },
            { label: 'Sponsors', value: (estimatedEarnings * 0.3).toFixed(2), growth: '+15%' },
            { label: 'Ads', value: (estimatedEarnings * 0.2).toFixed(2), growth: '+5%' },
          ].map(item => (
            <div key={item.label} className="p-3 rounded-xl bg-white/10 backdrop-blur-sm">
              <p className="text-xs text-white/60">{item.label}</p>
              <p className="text-lg font-bold">${item.value}</p>
              <div className="flex items-center gap-0.5 text-emerald-300 text-xs mt-0.5">
                <ArrowUpRight className="w-3 h-3" />
                {item.growth}
              </div>
            </div>
          ))}
        </div>

        {/* Tip */}
        {userProfile.onboardingComplete && (
          <div className="mt-4 p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
            <p className="text-xs text-white/80">
              <span className="font-semibold text-amber-300">AI Tip:</span> Increasing your posting frequency from {userProfile.weeklyPosts} to {userProfile.weeklyPosts + 2} posts/week could boost your estimated earnings by ~35%.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default FirstDollarTracker;
