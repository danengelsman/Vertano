import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Flame, FileText, Target, Trophy, TrendingUp, ArrowUpRight } from 'lucide-react';

const StatsCards: React.FC = () => {
  const { streak, drafts, challengeDays, badges, currentLevel, xp } = useAppContext();
  const publishedCount = drafts.filter(d => d.published).length;
  const avgScore = drafts.length > 0
    ? Math.round(drafts.reduce((sum, d) => sum + d.score, 0) / drafts.length)
    : 0;
  const completedDays = challengeDays.filter(d => d.completed).length;
  const earnedBadges = badges.filter(b => b.earned).length;

  const stats = [
    {
      label: 'Current Streak',
      value: `${streak.current} days`,
      icon: <Flame className="w-5 h-5" />,
      color: 'from-orange-500 to-amber-500',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-600',
      change: streak.current > 0 ? `Best: ${streak.longest}` : 'Start today!',
    },
    {
      label: 'Content Published',
      value: `${publishedCount + streak.totalPublished}`,
      icon: <FileText className="w-5 h-5" />,
      color: 'from-blue-500 to-cyan-500',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-600',
      change: `${drafts.filter(d => !d.published).length} drafts`,
    },
    {
      label: 'Avg. Content Score',
      value: avgScore > 0 ? `${avgScore}/100` : '--',
      icon: <Target className="w-5 h-5" />,
      color: 'from-emerald-500 to-green-500',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-600',
      change: avgScore >= 80 ? 'Excellent!' : avgScore > 0 ? 'Keep improving' : 'Create content',
    },
    {
      label: 'Challenge Progress',
      value: `${completedDays}/30`,
      icon: <Trophy className="w-5 h-5" />,
      color: 'from-violet-500 to-purple-500',
      bgColor: 'bg-violet-50',
      textColor: 'text-violet-600',
      change: `${earnedBadges} badges earned`,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map(stat => (
        <div
          key={stat.label}
          className="group relative overflow-hidden rounded-2xl bg-white border border-slate-200 p-5 hover:shadow-lg hover:border-slate-300 transition-all duration-300"
        >
          <div className="flex items-start justify-between mb-3">
            <div className={`w-11 h-11 rounded-xl ${stat.bgColor} flex items-center justify-center ${stat.textColor}`}>
              {stat.icon}
            </div>
            <div className="flex items-center gap-1 text-xs text-slate-400">
              <TrendingUp className="w-3 h-3" />
              <span>{stat.change}</span>
            </div>
          </div>
          <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
          <p className="text-sm text-slate-500 mt-0.5">{stat.label}</p>
          {/* Hover gradient accent */}
          <div className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-100 transition-opacity`} />
        </div>
      ))}
    </div>
  );
};

export default StatsCards;
