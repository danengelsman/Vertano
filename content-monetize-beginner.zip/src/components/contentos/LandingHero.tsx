import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Button } from '@/components/ui/button';
import {
  Zap, ArrowRight, PenTool, Target, DollarSign, Users,
  Sparkles, Trophy, Star, Play
} from 'lucide-react';


const features = [
  {
    icon: <PenTool className="w-6 h-6" />,
    title: 'AI Content Studio',
    description: 'Write, score, and format content for any platform with real-time AI feedback and a Content Score that helps you improve.',
    color: 'from-violet-500 to-indigo-600',
    bg: 'bg-violet-50',
    text: 'text-violet-600',
  },
  {
    icon: <DollarSign className="w-6 h-6" />,
    title: 'First Dollar Tracker',
    description: 'See exactly how close you are to earning your first dollar. We estimate revenue from affiliates, sponsors, and ads.',
    color: 'from-emerald-500 to-green-600',
    bg: 'bg-emerald-50',
    text: 'text-emerald-600',
  },
  {
    icon: <Target className="w-6 h-6" />,
    title: 'Personalized Roadmap',
    description: 'A month-by-month plan tailored to your niche and goals. From audience building to monetization.',
    color: 'from-amber-500 to-orange-600',
    bg: 'bg-amber-50',
    text: 'text-amber-600',
  },
  {
    icon: <Sparkles className="w-6 h-6" />,
    title: 'AI Niche Coach',
    description: 'Weekly content briefs, performance reviews, and personalized ideas matched to trending topics in your niche.',
    color: 'from-blue-500 to-cyan-600',
    bg: 'bg-blue-50',
    text: 'text-blue-600',
  },
  {
    icon: <Trophy className="w-6 h-6" />,
    title: '30-Day Challenge',
    description: 'A gamified journey from finding ideas to monetization. Earn badges, build streaks, and share your progress.',
    color: 'from-pink-500 to-rose-600',
    bg: 'bg-pink-50',
    text: 'text-pink-600',
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: 'Creator Community',
    description: 'Join cohorts, climb leaderboards, and share your Creator Journey page. Grow together with fellow creators.',
    color: 'from-purple-500 to-violet-600',
    bg: 'bg-purple-50',
    text: 'text-purple-600',
  },
];

const testimonials = [
  { name: 'Sarah K.', niche: 'Fitness', quote: 'I went from zero posts to earning $342/month in just 3 months. The AI coach kept me accountable.', streak: 47, avatar: 'S' },
  { name: 'Mike R.', niche: 'Tech Reviews', quote: 'The Content Score changed everything. I finally understand what makes a post perform well.', streak: 38, avatar: 'M' },
  { name: 'Jess L.', niche: 'Personal Finance', quote: 'The 30-day challenge got me hooked. Now I can\'t stop creating. My first sponsorship came on Day 25!', streak: 35, avatar: 'J' },
];

const stats = [
  { value: '12,000+', label: 'Active Creators' },
  { value: '$2.4M', label: 'Creator Earnings' },
  { value: '850K+', label: 'Posts Published' },
  { value: '94%', label: 'Completion Rate' },
];

const LandingHero: React.FC = () => {
  const { setShowOnboarding } = useAppContext();

  return (
    <div className="space-y-0">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-violet-950 to-indigo-950 py-20 lg:py-28">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-violet-500/10 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-500/5 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/10 text-sm text-white/80 mb-8">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>AI-Powered Content Creation Platform</span>
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold text-white leading-tight mb-6">
              From First Post to{' '}
              <span className="bg-gradient-to-r from-amber-400 via-yellow-300 to-orange-400 bg-clip-text text-transparent">
                First Dollar
              </span>
            </h1>
            <p className="text-lg lg:text-xl text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed">
              ContentOS is your AI-powered mentor that helps beginner creators build a content habit,
              grow their audience, and earn their first dollar — all in one platform.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button
                onClick={() => setShowOnboarding(true)}
                size="lg"
                className="gap-2 bg-white text-slate-900 hover:bg-white/90 shadow-2xl h-12 px-8 text-base"

              >
                Start Free — No Credit Card <ArrowRight className="w-5 h-5" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="gap-2 border-white/20 text-white hover:bg-white/10 h-12 px-8 text-base"

                onClick={() => {
                  const el = document.getElementById('features');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                <Play className="w-4 h-4" /> See How It Works
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-16 max-w-3xl mx-auto">
            {stats.map(stat => (
              <div key={stat.label} className="text-center p-4 rounded-xl bg-white/5 backdrop-blur-sm border border-white/10">
                <p className="text-2xl lg:text-3xl font-bold text-white">{stat.value}</p>
                <p className="text-xs text-white/50 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-violet-600 bg-violet-50 px-3 py-1 rounded-full">Features</span>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mt-4">Everything You Need to Succeed</h2>
            <p className="text-lg text-slate-500 mt-3 max-w-2xl mx-auto">
              A complete toolkit designed specifically for beginner creators who want to turn their passion into income.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map(feature => (
              <div
                key={feature.title}
                className="group p-6 rounded-2xl border border-slate-200 hover:border-slate-300 hover:shadow-xl transition-all duration-300"
              >
                <div className={`w-14 h-14 rounded-2xl ${feature.bg} ${feature.text} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-violet-600 bg-violet-50 px-3 py-1 rounded-full">How It Works</span>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mt-4">Three Steps to Your First Dollar</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: 1, title: 'Tell Us About You', desc: 'Answer a few questions about your niche, platforms, and monetization goals. We personalize everything.', icon: <Target className="w-8 h-8" />, color: 'from-blue-500 to-cyan-500' },
              { step: 2, title: 'Create & Publish', desc: 'Use our AI-powered editor to write, score, and format content. The 30-day challenge keeps you consistent.', icon: <PenTool className="w-8 h-8" />, color: 'from-violet-500 to-purple-500' },
              { step: 3, title: 'Earn Your First Dollar', desc: 'Follow your personalized roadmap to monetize through affiliates, sponsors, and digital products.', icon: <DollarSign className="w-8 h-8" />, color: 'from-emerald-500 to-green-500' },
            ].map(item => (
              <div key={item.step} className="relative text-center">
                <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${item.color} flex items-center justify-center text-white mx-auto mb-6 shadow-xl`}>
                  {item.icon}
                </div>
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-3 w-8 h-8 rounded-full bg-white border-2 border-slate-200 flex items-center justify-center text-sm font-bold text-slate-600">
                  {item.step}
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <span className="text-sm font-semibold text-violet-600 bg-violet-50 px-3 py-1 rounded-full">Testimonials</span>
            <h2 className="text-3xl lg:text-4xl font-bold text-slate-900 mt-4">Creators Love ContentOS</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map(t => (
              <div key={t.name} className="p-6 rounded-2xl bg-slate-50 border border-slate-200">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-slate-700 leading-relaxed mb-6">"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-400 to-indigo-500 flex items-center justify-center text-white font-bold">
                    {t.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.niche} · {t.streak}-day streak</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-violet-600 via-indigo-600 to-purple-700 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-96 h-96 bg-white/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-72 h-72 bg-white/5 rounded-full translate-x-1/2 translate-y-1/2" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Earn Your First Dollar?
          </h2>
          <p className="text-lg text-white/70 mb-8">
            Join 12,000+ creators who started their journey with ContentOS. It's free to begin.
          </p>
          <Button
            onClick={() => setShowOnboarding(true)}
            size="lg"
            className="gap-2 bg-white text-violet-700 hover:bg-white/90 shadow-2xl h-12 px-8 text-base"

          >
            Start Your Journey Free <ArrowRight className="w-5 h-5" />
          </Button>
          <p className="text-xs text-white/50 mt-4">No credit card required. Free tier includes 7 days of full access.</p>
        </div>
      </section>
    </div>
  );
};

export default LandingHero;
