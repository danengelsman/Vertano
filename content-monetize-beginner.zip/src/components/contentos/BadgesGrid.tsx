import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import {
  PenTool, Flame, Shield, Crown, Star, Gem, Globe, DollarSign, Layers, Users, Lock
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  pen: <PenTool className="w-5 h-5" />,
  flame: <Flame className="w-5 h-5" />,
  shield: <Shield className="w-5 h-5" />,
  crown: <Crown className="w-5 h-5" />,
  star: <Star className="w-5 h-5" />,
  gem: <Gem className="w-5 h-5" />,
  globe: <Globe className="w-5 h-5" />,
  dollar: <DollarSign className="w-5 h-5" />,
  layers: <Layers className="w-5 h-5" />,
  users: <Users className="w-5 h-5" />,
};

const BadgesGrid: React.FC = () => {
  const { badges } = useAppContext();
  const earnedCount = badges.filter(b => b.earned).length;

  return (
    <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden">
      <div className="p-5 border-b border-slate-100">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-slate-900">Achievements</h3>
          <span className="text-xs font-medium text-slate-500">{earnedCount}/{badges.length} earned</span>
        </div>
      </div>
      <div className="p-5 grid grid-cols-5 gap-3">
        {badges.map(badge => (
          <div
            key={badge.id}
            className="group relative flex flex-col items-center"
            title={`${badge.name}: ${badge.description}`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all ${
              badge.earned
                ? 'bg-gradient-to-br from-amber-400 to-orange-500 text-white shadow-lg shadow-amber-200 scale-100'
                : 'bg-slate-100 text-slate-300'
            }`}>
              {badge.earned ? iconMap[badge.icon] : <Lock className="w-4 h-4" />}
            </div>
            <p className={`text-[10px] mt-1.5 text-center leading-tight font-medium ${
              badge.earned ? 'text-slate-700' : 'text-slate-400'
            }`}>
              {badge.name}
            </p>
            {/* Tooltip on hover */}
            <div className="absolute -top-12 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
              <div className="bg-slate-900 text-white text-xs px-3 py-1.5 rounded-lg whitespace-nowrap shadow-lg">
                {badge.description}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BadgesGrid;
